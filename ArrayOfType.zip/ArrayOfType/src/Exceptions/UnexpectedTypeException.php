<?php

declare(strict_types=1);

namespace Rombarte\ArrayOfType\Exceptions;

class UnexpectedTypeException extends \Exception {}
